var searchData=
[
  ['addevent',['AddEvent',['../d1/dd6/classSensor.html#a87e6beb7000925904b352fb86c0fd94b',1,'Sensor']]],
  ['addstatsbyday',['AddStatsByDay',['../d1/dd6/classSensor.html#a55294472a10d0ab5763198d962ee5706',1,'Sensor']]],
  ['addstatsbyhour',['AddStatsByHour',['../d1/dd6/classSensor.html#aab7e3683f0d00dc00c84be5be49463a7',1,'Sensor']]],
  ['addstatsbysensor',['AddStatsBySensor',['../d1/dd6/classSensor.html#a3ce7f2c2ebb64a79563dcaf52fdfe836',1,'Sensor']]]
];

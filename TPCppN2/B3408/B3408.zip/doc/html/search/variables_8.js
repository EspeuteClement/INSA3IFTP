var searchData=
[
  ['n',['N',['../d5/d65/Sensor_8h.html#ab2b6b0c222cd1ce70d6a831f57241e59',1,'Sensor.h']]],
  ['number_5fof_5fdays',['NUMBER_OF_DAYS',['../d5/d65/Sensor_8h.html#a9de299bbc662d039da95cfcfa804d57d',1,'Sensor.h']]],
  ['number_5fof_5fhours',['NUMBER_OF_HOURS',['../d5/d65/Sensor_8h.html#ae5fedf65302c407863d5a4140d76e996',1,'Sensor.h']]],
  ['number_5fof_5fminutes',['NUMBER_OF_MINUTES',['../d5/d65/Sensor_8h.html#adc2490b3300de6d7d995fe9338eee278',1,'Sensor.h']]],
  ['number_5fof_5fstates',['NUMBER_OF_STATES',['../d5/d65/Sensor_8h.html#a178509449269ea067f51901413c95b55',1,'Sensor.h']]]
];

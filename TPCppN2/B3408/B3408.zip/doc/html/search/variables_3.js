var searchData=
[
  ['green',['GREEN',['../dc/dc5/classUtils.html#aba9c74f3554dac696ace1f3af9cd3479',1,'Utils']]]
];

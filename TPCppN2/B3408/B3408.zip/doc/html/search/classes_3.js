var searchData=
[
  ['sensor',['Sensor',['../d1/dd6/classSensor.html',1,'']]],
  ['stats',['Stats',['../d0/da3/structStats.html',1,'']]],
  ['statsrel',['StatsRel',['../d0/d61/structStatsRel.html',1,'']]]
];

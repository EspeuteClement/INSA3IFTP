/** @mainpage
* This application manages traffic sensors data and creates statistics and
* predictions according to it. For details about functionnalities please take a
* look at the rest of the documentation. We recommend starting by the IoEngine
* class in which you will find the description of the Input commands of the
* program.
* Please enjoy your reading !
*/

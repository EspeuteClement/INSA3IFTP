var searchData=
[
  ['bold',['BOLD',['../dc/dc5/classUtils.html#a0978fed66adff502d6e454eaf32a61fc',1,'Utils']]]
];

var searchData=
[
  ['parent',['parent',['../df/dd0/classNode.html#ad8184598cdea70e4bbdfd76f2b0f9e85',1,'Node']]]
];

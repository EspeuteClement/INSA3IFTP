var searchData=
[
  ['end_5fbold',['END_BOLD',['../dc/dc5/classUtils.html#a6a4b08e7055f715152639f63f8e60b97',1,'Utils']]],
  ['end_5fcolor',['END_COLOR',['../dc/dc5/classUtils.html#ad94379a477eea7a3c4eb57247dd8a98c',1,'Utils']]]
];

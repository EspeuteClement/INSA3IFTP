var searchData=
[
  ['id',['ID',['../d1/dd6/classSensor.html#a561205f062cc790f4013fae499d0cb0d',1,'Sensor']]],
  ['index',['index',['../d1/dd6/classSensor.html#a104c34ba65da43203a0208c62b66de69',1,'Sensor']]]
];
